package examples.replication;

import jade.content.AgentAction;

public class GetValue implements AgentAction {

}
