package examples.content.sfo;

public class ExpertProgrammer extends Programmer {
	private static final long serialVersionUID = 1L;

	private int bugsFixedPerHour;

	public int getBugsFixedPerHour() {
		return bugsFixedPerHour;
	}

	public void setBugsFixedPerHour(int bugsFixedPerHour) {
		this.bugsFixedPerHour = bugsFixedPerHour;
	}
}
