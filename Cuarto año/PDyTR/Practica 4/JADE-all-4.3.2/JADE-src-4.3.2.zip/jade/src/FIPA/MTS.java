/*
 * File: ./FIPA/MTS.JAVA
 * From: FIPA.IDL
 * Date: Mon Sep 04 15:08:50 2000
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package FIPA;
public interface MTS
    extends org.omg.CORBA.Object {
    void message(FIPA.FipaMessage aFipaMessage)
;
}
