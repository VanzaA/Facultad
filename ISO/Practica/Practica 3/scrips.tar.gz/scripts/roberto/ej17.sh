#!/bin/bash
ls | tr bcdefghijklmnopqrstuvwxyzBCDEFGHIJKLMNOPQRSTUVWXYZ BCDEFGHIJKLMNOPQRSTUVWXYZbcdefghijklmnopqrstuvwxyz | tr -d aA


